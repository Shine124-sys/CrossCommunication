import torch
import torchaudio
import whisper
from transformers import MarianMTModel, MarianTokenizer
from TTS.api import TTS
from fastapi import FastAPI, WebSocket
import uvicorn
import tempfile
import asyncio
from aiortc import RTCPeerConnection, MediaStreamTrack, RTCSessionDescription
import json
import yt_dlp
import ffmpeg
import pygame

# Load Whisper ASR model
asr_model = whisper.load_model("small")

# Supported translation models
TRANSLATION_MODELS = {
    "en-es": "Helsinki-NLP/opus-mt-en-es",
    "en-fr": "Helsinki-NLP/opus-mt-en-fr",
    "es-en": "Helsinki-NLP/opus-mt-es-en",
    "fr-en": "Helsinki-NLP/opus-mt-fr-en"
}

# Load TTS model
tts = TTS("tts_models/multilingual/multi-dataset/your_tts")

app = FastAPI()
pcs = set()
pygame.mixer.init()

class AudioTranslationTrack(MediaStreamTrack):
    kind = "audio"
    def __init__(self, track, src_lang, tgt_lang):
        super().__init__()
        self.track = track
        self.src_lang = src_lang
        self.tgt_lang = tgt_lang
        self.translator = MarianMTModel.from_pretrained(TRANSLATION_MODELS[f"{src_lang}-{tgt_lang}"])
        self.tokenizer = MarianTokenizer.from_pretrained(TRANSLATION_MODELS[f"{src_lang}-{tgt_lang}"])
    
    async def recv(self):
        frame = await self.track.recv()
        audio_data = frame.to_ndarray()
        
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp:
            torchaudio.save(temp.name, torch.tensor(audio_data), 16000)
            temp_path = temp.name
        
        result = asr_model.transcribe(temp_path, language=self.src_lang)
        text_original = result["text"]
        
        inputs = self.tokenizer(text_original, return_tensors="pt", padding=True, truncation=True)
        translated_tokens = self.translator.generate(**inputs)
        text_translated = self.tokenizer.decode(translated_tokens[0], skip_special_tokens=True)
        
        tts_output = f"output_{self.tgt_lang}.wav"
        tts.tts_to_file(text=text_translated, file_path=tts_output, speaker_wav=temp_path)
        
        return frame

@app.post("/offer")
async def offer(request: dict):
    params = json.loads(request.body)
    offer = RTCSessionDescription(sdp=params["sdp"], type=params["type"])
    pc = RTCPeerConnection()
    pcs.add(pc)
    
    @pc.on("track")
    def on_track(track):
        if track.kind == "audio":
            pc.addTrack(AudioTranslationTrack(track, params["src_lang"], params["tgt_lang"]))
    
    await pc.setRemoteDescription(offer)
    answer = await pc.createAnswer()
    await pc.setLocalDescription(answer)
    return {"sdp": pc.localDescription.sdp, "type": pc.localDescription.type}

@app.post("/youtube-translate")
async def youtube_translate(video_url: str, src_lang: str, tgt_lang: str):
    ydl_opts = {
        'format': 'bestaudio',
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'wav',
            'preferredquality': '192'
        }]
    }
    
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info_dict = ydl.extract_info(video_url, download=True)
        video_file = ydl.prepare_filename(info_dict)
        audio_file = video_file.replace(".webm", ".wav").replace(".mp4", ".wav")
    
    result = asr_model.transcribe(audio_file, language=src_lang)
    text_original = result["text"]
    
    translator = MarianMTModel.from_pretrained(TRANSLATION_MODELS[f"{src_lang}-{tgt_lang}"])
    tokenizer = MarianTokenizer.from_pretrained(TRANSLATION_MODELS[f"{src_lang}-{tgt_lang}"])
    inputs = tokenizer(text_original, return_tensors="pt", padding=True, truncation=True)
    translated_tokens = translator.generate(**inputs)
    text_translated = tokenizer.decode(translated_tokens[0], skip_special_tokens=True)
    
    tts_output = f"translated_{tgt_lang}.wav"
    tts.tts_to_file(text=text_translated, file_path=tts_output, speaker_wav=audio_file)
    
    # Play video and sync translated audio
    pygame.mixer.music.load(tts_output)
    pygame.mixer.music.play()
    
    ffmpeg.input(video_file).output("output_video.mp4").run()
    
    return {"original_text": text_original, "translated_text": text_translated, "audio": tts_output, "video": "output_video.mp4"}

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
